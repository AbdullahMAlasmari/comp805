from django.apps import AppConfig


class FlashcardsConfig(AppConfig):
    name = 'flashcards'
